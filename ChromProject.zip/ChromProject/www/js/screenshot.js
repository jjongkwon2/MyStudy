$(document).ready(function(){

  $("#save").click(saveButtonClick);
  $("#cancel").click(cancelButtonClicked);

});

function cancelButtonClicked(){
  window.close();
}

function setScreenshotUrl(url) {
  $("#target").attr("src", url);
}

function saveButtonClick(){
  var url = $("#target").attr("src");
  /*
    TODO : 이미지 이름 변경할 것 ( {앱이름}_{현재시간} )
  */
  download(url, "screenshot.png", "image/png");
}
